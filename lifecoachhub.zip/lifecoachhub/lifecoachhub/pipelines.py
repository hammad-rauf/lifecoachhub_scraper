# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import sqlite3

class LifecoachhubPipeline(object):
    def __init__(self):
        self.create_connection()
        self.create_table()
        pass

    def create_connection(self):
        self.conn = sqlite3.connect("lifecoachhub.db")
        self.curr = self.conn.cursor()

    def create_table(self):
        self.curr.execute(" drop table if exists coaches")

        self.curr.execute("create table coaches(name text,location text,website text,type_of_coach text,description text,social_links text,image text,url text)")

    def store_db(self,coaches):

        if coaches["name"]:
            self.curr.execute(f'insert into coaches values("{coaches["name"]}","{coaches["location"]}","{coaches["website"]}","{coaches["type_of_coach"]}","{coaches["description"]}","{coaches["social_links"]}","{coaches["image"]}","{coaches["url"]}")')

        self.conn.commit()

    def process_item(self, item, spider):
        self.store_db(item)
        return item
