from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import LifecoachhubItem

#from datetime import date


class LifeCoachHubSpider(CrawlSpider):

    name = "lifecoachhub"

    start_urls = [
                "https://www.lifecoachhub.com/coach-directory"
    ]

    rules = (
        Rule(LinkExtractor(restrict_css=([".next.control  a"]))),
        Rule(LinkExtractor(restrict_css=(".coachInfo h4  a")),callback="coach"),  
    )


    def coach(self, response):

        coaches = LifecoachhubItem()

        coaches["name"] = response.css(".coachInfo h1 span::text").extract()

        if coaches["name"]:
            coaches["name"] = "".join(coaches["name"])
            coaches["name"] = coaches["name"].replace("\n","")
            coaches["name"] = coaches["name"].replace("\t","")    
            coaches["name"]= coaches["name"].replace(" ","")
            coaches["name"] = " ".join(coaches["name"].split())
            

        coaches["location"] = response.css(".country span span::text").extract()
        
        if coaches["location"]:
            coaches["location"] = "".join(coaches["location"])
            coaches["location"] = coaches["location"].replace("\n","")
            coaches["location"] = coaches["location"].replace("\t","")    
            coaches["location"]= coaches["location"].replace(" ","")
            coaches["location"] = " ".join(coaches["location"].split())


        coaches["website"] = response.css(".live-link a::attr(href)").extract_first()
    
        
        coaches["type_of_coach"] = response.css(".degree::text").extract()
        if coaches["type_of_coach"]:
            coaches["type_of_coach"] = "".join(coaches["type_of_coach"])
            coaches["type_of_coach"] = coaches["type_of_coach"].replace("\n","")
            coaches["type_of_coach"] = coaches["type_of_coach"].replace("\t","")    
            coaches["type_of_coach"]= coaches["type_of_coach"].replace(" ","")
            coaches["type_of_coach"] = " ".join(coaches["type_of_coach"].split())

        coaches["description"] = response.css(".user-content.p1 p::text").extract_first()

        if coaches["description"]:
            coaches["description"] = coaches["description"].replace('"'," ")

        coaches["social_links"] = response.css(".social-media-ul a::attr(href)").extract()
        coaches["social_links"] = ",".join(coaches["social_links"])

        coaches["image"] = response.css(".image span img::attr(src)").extract_first()
        coaches["image"] = f"https://www.lifecoachhub.com/{coaches['image']}"

        coaches["url"] = response.url


        yield coaches
 